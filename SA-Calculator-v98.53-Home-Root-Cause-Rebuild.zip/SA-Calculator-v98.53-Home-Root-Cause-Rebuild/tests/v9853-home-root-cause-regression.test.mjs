import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = p => fs.readFileSync(path.join(root,p),'utf8');

test('v98.53 package, runtime, manifest and HTML identities are synchronized',()=>{
  const pkg=JSON.parse(read('package.json'));
  const html=read('index.html');
  const js=read('assets/js/app.js');
  const manifest=JSON.parse(read('manifest.webmanifest'));
  assert.equal(pkg.version,'1.98.53-v98.53');
  assert.match(html,/sa-build-version" content="1\.98\.53-v98\.53/);
  assert.match(html,/rebuild-v98\.53\.css/);
  assert.doesNotMatch(html,/rebuild-v98\.52\.css/);
  assert.match(js,/const APP_VERSION = '1\.98\.53-v98\.53'/);
  assert.equal(manifest.version,pkg.version);
});

test('old global Home-header suppression is removed from legacy CSS',()=>{
  const legacy=read('assets/css/rebuild-v98.50.css');
  assert.doesNotMatch(legacy,/#app-container\s*>\s*\.app-header\s*\{[^}]*display\s*:\s*none\s*!important/i);
  assert.doesNotMatch(legacy,/remove only the redundant in-app header/i);
});

test('authoritative Home CSS shows header on Home/Tools and hides it only on child screens',()=>{
  const css=read('assets/css/rebuild-v98.53.css');
  assert.match(css,/#app-container\s*>\s*\.app-header\s*\{[^}]*display\s*:\s*flex\s*!important/s);
  assert.match(css,/body\.tool-screen-active\s+#app-container\s*>\s*\.app-header\s*\{display:none!important\}/);
  assert.match(css,/#bottom-navigation\.bottom-navigation\[hidden\]\{display:none!important\}/);
  assert.match(css,/#screen-calc\s*>\s*\.main-keypad\s*\{[^}]*grid-template-columns:repeat\(4,minmax\(0,1fr\)\)!important/s);
  assert.match(css,/grid-template-rows:repeat\(5,minmax\(48px,1fr\)\)!important/);
  assert.match(css,/--sa-home-nav-height:78px/);
  assert.match(css,/margin:16px 8px 10px/);
});

test('Home keypad retains every existing calculation hook and approved geometry',()=>{
  const html=read('index.html');
  const home=html.match(/<div class="screen active" id="screen-calc">([\s\S]*?)<\/div>\s*<section class="screen scientific-screen"/)[1];
  for (const key of ['C','±','%','/','7','8','9','*','4','5','6','-','1','2','3','+','0','.','=']) assert.ok(home.includes(`data-calc="${key}"`),`missing ${key}`);
  assert.match(home,/class="key-btn zero-key" data-calc="0"/);
  assert.match(home,/id="calc-expr"/);
  assert.match(home,/id="calc-val"/);
  assert.match(html,/data-bottom-nav="settings"/);
});

test('Home header controls preserve existing navigation and history handlers',()=>{
  const html=read('index.html');
  const js=read('assets/js/app.js');
  for (const id of ['btn-drawer-open','btn-header-history','btn-tools-more']) assert.ok(html.includes(`id="${id}"`));
  assert.match(js,/getElementById\('btn-header-history'\)[\s\S]*?getElementById\('btn-history-open'\)\?\.click\(\)/);
  assert.match(js,/document\.getElementById\('btn-history-open'\)\.onclick = openHistoryModal/);
  assert.match(js,/document\.body\.classList\.toggle\('tool-screen-active', screenId !== 'calc' && screenId !== 'tools'\)/);
});

test('Android build uses only v98.53 authoritative Home CSS and cache namespace',()=>{
  const script=read('scripts/prepare-android-web.mjs');
  const sw=read('service-worker.js');
  const wf=read('SA-Calculator-v98.53-Android-Workflow.yml');
  assert.match(script,/rebuild-v98\.53\.css/);
  assert.doesNotMatch(script,/rebuild-v98\.52\.css/);
  assert.match(sw,/sa-calculator-v98-53-home-authoritative-rebuild-v9853/);
  assert.match(wf,/1\.98\.53-v98\.53/);
  assert.match(wf,/1098053/);
});
