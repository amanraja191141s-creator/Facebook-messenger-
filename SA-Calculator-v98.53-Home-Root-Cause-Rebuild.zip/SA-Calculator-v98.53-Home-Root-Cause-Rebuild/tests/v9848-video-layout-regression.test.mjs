import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('v98.48 scientific screen reserves space for all 5 numeric keypad rows and memory row', () => {
  const css = read('assets/css/rebuild-v98.48.css');
  assert.match(css, /\.scientific-keypad\s*\{[\s\S]*?grid-template-rows:\s*repeat\(5/);
  assert.match(css, /\.scientific-keypad\s*\{[\s\S]*?min-height:\s*190px/);
  assert.match(css, /\.scientific-memory-row\s*\{[\s\S]*?min-height:\s*30px/);
  assert.match(css, /\.scientific-function-grid\s*\{[\s\S]*?overflow-y:\s*auto/);
});

test('scientific expression editor preserves caret and horizontal scroll while typing', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /const editorValueChanged = editor\.value !== sci\.expression/);
  assert.match(js, /if \(editorValueChanged\) \{ editor\.value = sci\.expression; editor\.scrollLeft = editor\.scrollWidth; \}/);
  assert.match(js, /editor\.scrollLeft = editor\.scrollWidth/);
});

test('Tools grid cannot overlap search/categories and stays a stable two-column grid', () => {
  const css = read('assets/css/rebuild-v98.48.css');
  assert.match(css, /#screen-tools \.premium-tools-grid\s*\{[\s\S]*?display:\s*grid !important/);
  assert.match(css, /grid-template-columns:\s*repeat\(2,\s*minmax\(0,\s*1fr\)\) !important/);
  assert.match(css, /#screen-tools \.tools-category-list\s*\{[\s\S]*?flex:\s*0 0 auto !important/);
  assert.match(css, /#screen-tools \.premium-tool-card\s*\{[\s\S]*?width:\s*100% !important/);
});

test('v98.48 stylesheet is compiled into Android bundle and cached by a new SW identity', () => {
  const builder = read('scripts/prepare-android-web.mjs');
  const html = read('index.html');
  const sw = read('service-worker.js');
  assert.match(builder, /rebuild-v98\.48\.css/);
  assert.match(html, /rebuild-v98\.48\.css/);
  assert.match(sw, /sa-calculator-v98-53-home-authoritative-rebuild-v9853/);
});

test('v98.49 release identity and workflow copy are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const wf = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.53-v98.53');
  assert.equal(manifest.version, '1.98.53-v98.53');
  assert.equal(wf, read('SA-Calculator-v98.53-Android-Workflow.yml'));
  assert.match(wf, /1098053/);
});
