# SA Calculator v98.53 — Home Screen Root-Cause Rebuild

## Root cause found in v98.52
The v98.50 stylesheet still contained `#app-container > .app-header{display:none!important}`. The v98.52 layer styled the header but did not undo that higher-specificity important declaration. As a result, the approved header could remain hidden. The v98.50 Home keypad overrides also duplicated rules already owned by the later Home layer.

## Removal and replacement
- Removed the stale global header suppression from v98.50.
- Removed redundant v98.50 Home keypad styling so one final layer owns Home geometry.
- Removed the v98.52 Home stylesheet from the active build chain.
- Added `rebuild-v98.53.css` as the single authoritative Home presentation layer.
- Header is visible on Home and Tools; it is hidden on child tool/settings/favorites screens that use their contextual toolbar.

## Approved reference geometry
- Header: 64dp (56dp on short windows); 48dp touch controls; 40dp brand mark.
- Display: 22% responsive flex basis, 138–190dp bounds, 8dp side inset, 18dp radius.
- Keypad: four columns by five rows; 8dp standard gap; 8dp side inset; zero spans two columns; minimum 48dp key target.
- Navigation: five equal destinations; 78dp total (68dp on short windows), safe-area aware.
- Blue primary keys: AC, ÷, ×, −, +, =; navy utility and number keys.
- Light theme changes colors without changing geometry.

## Behavior preserved
All existing `data-calc` attributes, expression/result element IDs, calculation handlers, History action, drawer actions, bottom navigation routing, and child-tool toolbar behavior are preserved.

## Verification boundaries
Automated source tests, JavaScript syntax, YAML parse, web bundle generation, ZIP integrity, and headless browser rendering are checked separately. Physical-device installation, OEM WebView rendering, touch testing, and performance profiling still require an Android device.
