# SA Calculator — Micro-level source audit and fixes (v98.42)

Audit basis: supplied `SA-Calculator-v98.41-Premium-20Plus-Research-Final.zip`, extracted and inspected directly. Baseline `npm test` run before changes: 293 passed, 0 failed.

## Verified weaknesses in the supplied v98.41 archive

1. **CSS delivery was fragmented.** `index.html` loaded nine stylesheet files (base plus eight rebuild layers). The same cascade was spread across multiple render-blocking requests.
2. **The CSS source/runtime distinction was unclear.** `rebuild-v98.36.css` was present in the service-worker precache and Android builder requirements although it was not linked by the HTML runtime.
3. **Archive identity was misleading.** The downloaded archive was named v98.41 but its internal top-level directory was `SA-Calculator-v98.40-Premium-System-Rebuild`.
4. **Release instructions were stale.** The README still described v98.40 and pointed to an older workflow filename.
5. **Workflow duplication caused ambiguity.** Five root-level YAML copies plus the active `.github/workflows/main.yml` carried the same workflow, including old versioned filenames.
6. **The visual reference was not runtime evidence.** The 18-screen collage was a generated design reference, not an image captured from the running APK.
7. **Automated UI checks were source-level.** The 293 baseline tests checked parser logic, DOM selectors, CSS text and bundle contents; they did not measure actual Android WebView pixels, touch latency or memory.
8. **Scientific Calculator is a modal/mode, not an independent registered screen.** The drawer exposes it as a tool entry, but the underlying route remains the Calculator screen.
9. **Dependency lock was absent.** `package.json` used caret ranges and there was no package-lock. A lockfile could not be generated in this environment because the npm registry was unreachable (offline attempt returned ENOTCACHED; online attempt timed out).

## v98.42 fixes implemented

1. **One production CSS request:** retained the old CSS source layers and exact cascade order, renamed the original base source to `assets/css/app-base.css`, and generated one `assets/css/app.css` bundle. `index.html` now loads only that bundle.
2. **Reproducible CSS generation:** `scripts/prepare-android-web.mjs` verifies every source layer, regenerates the bundle, then copies the web assets into `www/`.
3. **Lean offline cache:** the service worker precaches the single production stylesheet instead of separately precaching unused/duplicate CSS layers. Cache identity is `sa-calculator-v98-42-single-css-release`.
4. **Clean release identity:** package, manifest, HTML, runtime, workflow and Android versionCode now agree on `1.98.42-v98.42` / `1098042`.
5. **Clean archive structure:** final ZIP has a matching v98.42 top-level directory.
6. **Workflow de-duplication:** one active workflow remains at `.github/workflows/main.yml`; one byte-identical downloadable workflow remains at `SA-Calculator-v98.42-Android-Workflow.yml`. Obsolete root aliases were removed.
7. **Fresh documentation:** README and changelog now describe v98.42 rather than v98.40.
8. **Pinned direct dependency versions:** removed caret ranges from direct Capacitor dependencies to reduce unplanned top-level version drift.
9. **Regression coverage:** added checks for one linked production stylesheet, preservation of all CSS source layers, bundle regeneration, service-worker cache behavior, and single canonical workflow.

## Preserved systems

Existing calculator parser/arithmetic, 18 inventory-defined app destinations, scientific calculator modal, currency provider/freshness logic, unit conversion, tool calculation handlers, theme/settings, history, favorites, accessibility labels, Android branding and safe-area handling were retained.

## Verification performed for v98.42

- Baseline: 293/293 tests passed before edits.
- Final: 296/296 tests passed after edits.
- `npm run build:web`: passed; 19 required source assets verified and nine CSS source layers consolidated into one production stylesheet.
- JavaScript syntax checks: passed for app, localization, theme bootstrap, currency names, server, service worker and build scripts.
- Workflow copies: byte-identical.
- YAML parse and ZIP integrity: verified during packaging.

## Remaining release gates — not represented as fixed

- No package-lock was generated because registry access was unavailable; direct dependency ranges are exact, but transitive dependency reproducibility still needs a lockfile.
- Hosted GitHub Actions APK build was not run here.
- No physical Android installation, screenshot pixel comparison, TalkBack pass, touch-latency benchmark, memory profiling, battery test or long-session test was possible here.
- The generated 18-screen collage remains a design reference, not a screenshot of the v98.42 runtime.
