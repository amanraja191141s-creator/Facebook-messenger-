# QA Results — SA Calculator v98.52

## Automated verification
- Node regression suite: 339 tests passed, 0 failed.
- JavaScript syntax checks: passed (`assets/js/app.js`, `scripts/prepare-android-web.mjs`).
- Android web bundle generation: passed; 28 required source assets verified and 18 CSS source layers consolidated.
- Workflow YAML parsing: passed.
- Package / runtime / HTML / PWA manifest identity: `1.98.52-v98.52`.
- Android versionCode: `1098052`.
- GitHub Actions workflow copies: identical.
- Service worker cache namespace: `sa-calculator-v98-52-home-screen-redesign-v9852`.
- Final Home CSS layer present in source and generated `www` bundle.
- ZIP integrity: verified after packaging.

## Scope of changes
- Approved Home screen design applied to the actual Home screen markup/styles.
- Existing calculator action attributes and calculation engine preserved.
- History header action wired to existing History modal.
- Home label applied to first bottom-navigation destination.
- Responsive dark/light, compact-height, narrow-width and landscape Home styles added.
- Existing tools, scientific screen, settings, history, favorites and converter implementations retained.

## Not claimed as verified
- A physical Android device screenshot comparison was not completed.
- A hosted GitHub Actions Gradle build and APK installation were not run in this environment.
- Touch latency, memory use, battery use and real-device performance require device testing.
