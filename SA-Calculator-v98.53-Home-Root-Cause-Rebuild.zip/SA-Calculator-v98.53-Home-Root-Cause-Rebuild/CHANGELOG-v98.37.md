# SA Calculator v98.37 — complete 18-screen UI and Android bundle hardening

## Changes
- Retains all 18 existing screen IDs and all calculation/navigation behavior.
- Adds width containment for tool cards, form rows, inputs, selectors and long result values to prevent narrow WebView overflow.
- Adds the v98.37 stylesheet to HTML, service-worker precache, Android web-bundle required assets and CI post-build verification.
- Updates the release identity and cache namespace to prevent stale v98.36 assets from being reused.
- Keeps the Android workflow's exact-source selection and APK identity checks.

## Release identity
- App version: `1.98.37-v98.37`
- Android versionCode: `1098037`

## Validation boundary
Automated source tests, syntax checks, Android web bundle checks, YAML parsing and ZIP integrity are run locally. Hosted Android APK generation and physical-device visual/performance validation remain separate checks.
